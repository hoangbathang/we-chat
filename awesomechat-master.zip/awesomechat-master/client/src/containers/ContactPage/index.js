const ContactPage  = () => null;

export default ContactPage;
